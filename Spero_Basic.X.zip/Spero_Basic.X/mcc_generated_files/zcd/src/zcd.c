/**
 * ZCD Generated Driver File.
 * 
 * @file zcd.c
 * 
 * @ingroup  zcd
 * 
 * @brief This file contains the API implementation for the ZCD driver.
 *
 * @version ZCD Driver Version 2.11.0
*/
/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

/**
   Section: Included Files
*/

#include <xc.h>
#include "../zcd.h"

/**
  Section: ZCD Module APIs
*/

void ZCD_Initialize(void)
{
    // Set the ZCD to the options selected in the User Interface
  
    //ZCDINTN disabled; ZCDINTP enabled; ZCDPOL not inverted; ZCDEN enabled; 
    ZCDCON = 0x82;

    // Clearing IF flag before enabling the interrupt
    PIR2bits.ZCDIF = 0;

    // Enabling ZCD interrupt
    PIE2bits.ZCDIE = 1;
}

bool ZCD_IsLogicLevel(void)
{
    // Return ZCD logic level depending on the output polarity selected
    return (ZCDCONbits.ZCDOUT);
}
 
void ZCD_ISR(void)
{
    // Clear the ZCD interrupt flag
    PIR2bits.ZCDIF = 0;
}

/**
 End of File
*/