/*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * Ing. Bruno Silva
*/

#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/i2c_client/i2c_client_interface.h"
#include "mcc_generated_files/uart/eusart1.h"  // <-- Ajusta la ruta si tu archivo se encuentra en otra carpeta
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>

#define NUM_SENSORS 16

// Buffer para almacenar 16 valores de 16 bits (32 bytes en total)
static uint16_t sensorValues[NUM_SENSORS];
static uint8_t dataBuffer[NUM_SENSORS * 2];
static uint8_t byteIndex = 0;

// Bandera para indicar que hay nuevos datos de sensores
volatile bool newSensorData = false;

/*
 * Callback para manejar la recepci�n de datos I2C.
 * Se invoca cada vez que el maestro (Arduino) env�a un byte.
 */
bool I2C1_ClientCallback(i2c_client_transfer_event_t clientEvent)
{
    // Leer el byte que llega
    uint8_t receivedByte = I2C1_Client.ReadByte();
    dataBuffer[byteIndex++] = receivedByte;
    
    // Si ya se recibieron los 32 bytes (16 valores � 2 bytes)
    if (byteIndex >= (NUM_SENSORS * 2))
    {
        // Reconstruir los 16 valores de 16 bits
        for (int i = 0; i < NUM_SENSORS; i++)
        {
            sensorValues[i] = ((uint16_t)dataBuffer[2 * i] << 8) | dataBuffer[2 * i + 1];
        }
        // Reiniciar el �ndice para la pr�xima recepci�n
        byteIndex = 0;
        
        // Indicar que hay nuevos datos disponibles
        newSensorData = true;
    }
    return true;  // Indica que el evento fue manejado correctamente
}

/*
 * Redirige la salida de printf() hacia EUSART1.
 * Cada car�cter que se imprima por printf() se enviar� v�a UART.
 */
void putch(char data)
{
    EUSART1_Write(data);
}

/*
    Main application
*/
int main(void)
{
    // Inicializa el sistema (drivers, pines, reloj, etc.)
    SYSTEM_Initialize();
    
    // Habilitar interrupciones globales y perif�ricas
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();
    
    // Registrar la funci�n callback para la recepci�n I2C
    I2C1_Client.CallbackRegister(I2C1_ClientCallback);
    
    // Mensaje inicial por UART (para comprobar que la comunicaci�n funciona)
    printf("Inicio de comunicacion I2C y depuracion UART\r\n");
    
    while(1)
    {
        // Ejecutar las tareas del driver I2C (manejo de eventos)
        I2C1_Client.Tasks();
        
        // Si se han recibido nuevos datos, impr�melos por UART
        if (newSensorData)
        {
            printf("Valores de sensores recibidos:\r\n");
            for (int i = 0; i < NUM_SENSORS; i++)
            {
                printf("%u ", sensorValues[i]);
            }
            printf("\r\n");
            
            // Resetear la bandera
            newSensorData = false;
        }
        
        // Otras tareas del bucle principal, si las hubiera
    }    
}
