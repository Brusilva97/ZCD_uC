/*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * Ing. Bruno Silva
*/

#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/i2c_client/i2c_client_interface.h"
#include "mcc_generated_files/uart/eusart1.h"  
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>

#define NUM_SENSORS 16

// Buffer para almacenar 16 valores de 16 bits (32 bytes totales)
static uint16_t sensorValues[NUM_SENSORS];
static uint8_t dataBuffer[NUM_SENSORS * 2];
static uint8_t byteIndex = 0;

// Bandera para indicar que se han recibido nuevos datos
volatile bool newSensorData = false;

/*
 * Callback para manejar la recepci�n de datos I2C.
 * Se invoca cada vez que el maestro (Arduino) env�a un byte.
 */
bool I2C1_ClientCallback(i2c_client_transfer_event_t clientEvent)
{
    // Usamos RX_READY para detectar que el maestro ha enviado datos
    if(clientEvent == I2C_CLIENT_TRANSFER_EVENT_RX_READY)
    {
        uint8_t receivedByte = I2C1_Client.ReadByte();
        dataBuffer[byteIndex++] = receivedByte;
 
        if (byteIndex >= (NUM_SENSORS * 2))
        {
            for (int i = 0; i < NUM_SENSORS; i++)
            {
                sensorValues[i] = ((uint16_t)dataBuffer[2*i] << 8) | dataBuffer[2*i + 1];
            }
            byteIndex = 0;
            newSensorData = true;
        }
    }
    // Actualmente no se define un evento para solicitudes de lectura,
    // por lo que no se env�a una respuesta aqu�.
    return true;
}

/*
 * Redirige la salida de printf() hacia EUSART1.
 * Cada car�cter enviado con printf() se transmitir� con EUSART1_Write().
 */
void putch(char data)
{
    EUSART1_Write(data);
}

/*
    Main application
*/
int main(void)
{
    // Inicializa el sistema (drivers, pines, reloj, etc.)
    SYSTEM_Initialize();
    
    // Habilita interrupciones globales y perif�ricas
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();
    
    // Registrar la funci�n callback para la recepci�n de datos I2C
    I2C1_Client.CallbackRegister(I2C1_ClientCallback);
    
    // Mensaje inicial de depuraci�n v�a UART
    printf("Inicio de comunicacion I2C y depuracion UART\r\n");
    
    while(1)
    {
        // Ejecuta las tareas del driver I2C para gestionar eventos
        I2C1_Client.Tasks();
        
        // Si se han recibido nuevos datos, imprimirlos por UART
        if(newSensorData)
        {
            printf("Valores de sensores recibidos:\r\n");
            for (int i = 0; i < NUM_SENSORS; i++)
            {
                printf("%u ", sensorValues[i]);
            }
            printf("\r\n");
            newSensorData = false;
        }
    }    
}
