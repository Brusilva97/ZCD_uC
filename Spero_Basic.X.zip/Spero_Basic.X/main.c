/*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * Ing. Bruno Silva
*/

#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/i2c_client/i2c_client_interface.h"
#include "mcc_generated_files/uart/eusart1.h"  // <--- SIN "src" en la ruta
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>

#define NUM_SENSORS 16

// Buffer para almacenar 16 valores de 16 bits (32 bytes totales)
static uint16_t sensorValues[NUM_SENSORS];
static uint8_t dataBuffer[NUM_SENSORS * 2];
static uint8_t byteIndex = 0;

// Bandera para indicar que se han recibido nuevos datos
volatile bool newSensorData = false;

/*
 * Callback para manejar la recepci�n de datos I2C.
 * Se invoca cada vez que el maestro (Arduino) env�a un byte.
 */
bool I2C1_ClientCallback(i2c_client_transfer_event_t clientEvent)
{
    // Leer el byte recibido usando la funci�n del driver
    uint8_t receivedByte = I2C1_Client.ReadByte();
    dataBuffer[byteIndex++] = receivedByte;
    
    // Si se han recibido 32 bytes (16 valores � 2 bytes)
    if (byteIndex >= (NUM_SENSORS * 2))
    {
        for (int i = 0; i < NUM_SENSORS; i++)
        {
            // Reconstruir cada valor de 16 bits
            sensorValues[i] = ((uint16_t)dataBuffer[2*i] << 8) | dataBuffer[2*i + 1];
        }
        byteIndex = 0;
        newSensorData = true;
    }
    return true;  // Indica que el evento fue manejado
}

/*
 * Redirige la salida de printf() hacia EUSART1.
 * Cada car�cter que se env�e a trav�s de printf() se enviar� con EUSART1_Write().
 */
void putch(char data)
{
    EUSART1_Write(data);
}

/*
    Main application
*/
int main(void)
{
    // Inicializa el sistema (drivers, pines, reloj, etc.)
    SYSTEM_Initialize();
    
    // Habilitar interrupciones globales y perif�ricas
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();
    
    // Registrar la funci�n callback para la recepci�n de datos I2C
    I2C1_Client.CallbackRegister(I2C1_ClientCallback);
    
    // Mensaje inicial de depuraci�n v�a UART
    printf("Inicio de comunicacion I2C y depuracion UART\r\n");
    
    while(1)
    {
        // Ejecutar las tareas del driver I2C para gestionar eventos
        I2C1_Client.Tasks();
        
        // Si se han recibido nuevos datos, imprimirlos por UART
        if(newSensorData)
        {
            printf("Valores de sensores recibidos:\r\n");
            for (int i = 0; i < NUM_SENSORS; i++)
            {
                printf("%u ", sensorValues[i]);
            }
            printf("\r\n");
            newSensorData = false;
        }
    }    
}
